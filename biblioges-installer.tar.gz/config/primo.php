<?php

return [
    'api_key' => env('PRIMO_API_KEY', 'l8xx97a02ce2328f496bb59a58bee79148dd'),
    'inst' => env('PRIMO_INST', '56UCN_INST'),
    'vid' => env('PRIMO_VID', '56UCN_INST:UCN'),
]; 