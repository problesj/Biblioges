<?php

return [
    'migrations' => [
        '2024_03_20_000000_create_asignaturas_table.php'
    ],
    'seeders' => [
        'CarreraSeeder.php',
        'AsignaturaSeeder.php'
    ]
]; 