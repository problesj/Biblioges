<?php
// Log para depuración
error_log("Datos de sesión en la plantilla: " . print_r($_SESSION, true));
?>
<!DOCTYPE html>
<html lang="es"> 